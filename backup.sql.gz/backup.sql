--
-- PostgreSQL database dump
--

\restrict u2gEqHSsAqKIy5xWKO9HK7J9OUb5dlPjpbRhgZ40PDPDwkOzLeREIlRWDFOk6v3

-- Dumped from database version 17.10 (Debian 17.10-1.pgdg13+1)
-- Dumped by pg_dump version 17.10 (Debian 17.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: transacciones; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.transacciones (
    id integer NOT NULL,
    fecha timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    monto numeric(10,2) NOT NULL,
    descripcion character varying(255) NOT NULL,
    estado character varying(50) DEFAULT 'COMPLETADA'::character varying
);


ALTER TABLE public.transacciones OWNER TO admin;

--
-- Name: transacciones_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.transacciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.transacciones_id_seq OWNER TO admin;

--
-- Name: transacciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.transacciones_id_seq OWNED BY public.transacciones.id;


--
-- Name: transacciones id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.transacciones ALTER COLUMN id SET DEFAULT nextval('public.transacciones_id_seq'::regclass);


--
-- Data for Name: transacciones; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.transacciones (id, fecha, monto, descripcion, estado) FROM stdin;
1	2026-07-23 03:42:46.870497	150.50	Pago de servicios - Agua	COMPLETADA
2	2026-07-23 03:42:46.870497	45.00	Suscripción mensual - Software	COMPLETADA
3	2026-07-23 03:42:46.870497	1200.00	Nómina - Empleado 1	COMPLETADA
4	2026-07-23 03:42:46.870497	850.75	Compra de equipos de oficina	COMPLETADA
5	2026-07-23 03:42:46.870497	20.00	Recarga de saldo móvil	COMPLETADA
6	2026-07-23 03:42:46.870497	340.20	Pago a proveedores - Limpieza	COMPLETADA
7	2026-07-23 03:42:46.870497	500.00	Alquiler de oficina - Mensualidad	COMPLETADA
8	2026-07-23 03:42:46.870497	75.50	Mantenimiento de servidores	COMPLETADA
9	2026-07-23 03:42:46.870497	110.00	Publicidad en redes sociales	COMPLETADA
10	2026-07-23 03:42:46.870497	95.25	Compra de insumos de cafetería	COMPLETADA
11	2026-07-23 03:42:46.870497	2200.00	Venta de servicios de consultoría	COMPLETADA
12	2026-07-23 03:42:46.870497	15.99	Licencia de antivirus	COMPLETADA
13	2026-07-23 03:42:46.870497	300.00	Bono por cumplimiento de metas	COMPLETADA
14	2026-07-23 03:42:46.870497	55.60	Gastos de representación - Almuerzo	COMPLETADA
15	2026-07-23 03:42:46.870497	180.00	Renovación de dominios web	COMPLETADA
\.


--
-- Name: transacciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.transacciones_id_seq', 15, true);


--
-- Name: transacciones transacciones_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.transacciones
    ADD CONSTRAINT transacciones_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict u2gEqHSsAqKIy5xWKO9HK7J9OUb5dlPjpbRhgZ40PDPDwkOzLeREIlRWDFOk6v3

